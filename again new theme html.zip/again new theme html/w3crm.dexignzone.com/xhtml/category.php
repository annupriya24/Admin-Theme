<? include('header.php');
if(isset($_SESSION['type']))
{
	header("location:index.php");
} ?>
	<? 
	include('database_connection.php');
if($_POST["Submit"]) {
	  
	$category_id=addslashes($_POST['category_id']); 
    $brand_id=addslashes($_POST['brand_id']); 
	$product_name=addslashes($_POST['product_name']); 
	$product_description=addslashes($_POST['product_description']); 
	$product_quantity=addslashes($_POST['product_quantity']);
	$rack_no=addslashes($_POST['rack_no']);
    $product_unit=addslashes($_POST['product_unit']); 
	$product_base_price=addslashes($_POST['product_base_price']); 
	$product_tax=addslashes($_POST['product_tax']); 
	$sgst=addslashes($_POST['sgst']); 
	$cgst=addslashes($_POST['cgst']);
    $igst=addslashes($_POST['igst']); 
	$freight=addslashes($_POST['freight']); 
	$total_price=addslashes($_POST['total_price']); 
	$net_value=addslashes($_POST['net_value']); 
	$product_minimum_order=addslashes($_POST['product_minimum_order']);
    $product_enter_by=addslashes($_POST['product_enter_by']);
    $product_status=addslashes($_POST['product_status']);
    $product_date=addslashes($_POST['product_date']);
    
$img=$_FILES['filstor']['name'];
$tmpName=$_FILES['filstor']['tmp_name'];


//echo $time;

  if($img<>"")
  {
  $ext = strrchr($img, ".");

   $filter_name=str_replace(" ","-",$img);
   $filter_name=str_replace(".","-",$filter_name);    
$filter_name=strtolower($filter_name);

   // then create a new random name
   $newName = $filter_name."-".substr(md5(rand() * time()),0,5) . $ext;
   // then create a new random name 

   // the album image will be saved here
   $imgPath =  "photo/". $newName; 
   
 
   
 
  move_uploaded_file($tmpName,"photo/".$newName);
  }
$sql2="insert into  `product` set  

                                   

                                  `category_id`= '$category_id',   
                                  `brand_id`= '$brand_id',   
                                  `product_name`= '$product_name', 
                                  `photo`='$photo', 
                                  `product_description`= '$product_description',   
                                  `product_quantity`= '$product_quantity',
                                  `rack_no`= '$rack_no',
                                  `product_unit`= '$product_unit',   
                                  `product_base_price`= '$product_base_price',   
                                  `product_tax`= '$product_tax',   
                                  `sgst`= '$sgst',   
                                  `cgst`= '$cgst',
                                  `igst`= '$igst',
                                  `freight`= '$freight',
                                  `total_price`='$total_price',
                                  `net_value`='$net_value',
                                  `product_minimum_order`='$product_minimum_order',
                                  `product_enter_by`= '$product_enter_by',
                                  `product_status`= '$product_status', 
                                  `product_date`= now()
                                   


                                    ";


mysqli_query($conn,$sql2) or die(mysqli_error($conn));



            header('location: product.php?msg=success');

         }
	
	 ?>	
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->	
			<div class="page-titles">
				<ol class="breadcrumb">
					<li><h5 class="bc-title">Category</h5></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">
						<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M2.125 6.375L8.5 1.41667L14.875 6.375V14.1667C14.875 14.5424 14.7257 14.9027 14.4601 15.1684C14.1944 15.4341 13.8341 15.5833 13.4583 15.5833H3.54167C3.16594 15.5833 2.80561 15.4341 2.53993 15.1684C2.27426 14.9027 2.125 14.5424 2.125 14.1667V6.375Z" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M6.375 15.5833V8.5H10.625V15.5833" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
						Home </a>
					</li>
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Category</a></li>
				</ol>
				
			</div>
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-3 col-xxl-4">
						<div class="card h-auto">
							<div class="card-header">
								<h4 class="heading mb-0">Add New Category</h4>
							</div>
							<div class="card-body">
								<form class="finance-hr">
									<div class="form-group mb-3">
										<label class="text-secondary font-w500"> Category Title<span class="text-danger">*</span>
									  </label>
									  <input type="text" class="form-control"  placeholder="Category Title" name="category_name" id="category_name">
									</div>
									
									<div class="form-group mb-3">
										<label class="text-secondary">Status<span class="text-danger">*</span>
									  </label>
									  <select class="default-select form-control">
								      <option  data-display="Select">Please select</option>
								      <option value="Active">Active</option>
								      <option value="Deactivate">Deactivate</option>
							          </select>
									</div>
									<button type="submit" name="Submit" class="btn btn-primary mb-3">Confirm</button>
								</form>
							</div>
						</div>
					</div>
					<div class="col-xl-9 col-xxl-8">
						<div class="card">
							<div class="card-body p-0">
								<div class="table-responsive active-projects manage-client">
								<div class="tbl-caption">
									<h4 class="heading mb-0">Category List</h4>
								</div>
								<? $csql=mysqli_query($conn, "select * from category order by category_id"); 
								?>
									<table id="empoloyees-tbl1" class="table">
										<thead>
											<tr>
												<th>Category Id</th>
												<th>Category Name</th>
												<th>Category Status</th>
												<th>Action</th>
											</tr>
										</thead>
										<? while($row=mysqli_fetch_array($csql)){ ?>
										<tbody>
											<tr>
												
												<td><span><? echo $row['category_id'];?></span></td>
												<td>
													<span><? echo $row['category_name'];?></span>
												</td>
												<td>
													<span><? echo $row['category_status'];?></span>
												</td>
												<td>
													<div class="d-flex">
									
												<a href="category.php?category_id=<? echo $row['category_id'];?>" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a>
												<a href="javascript:resume_id('<? echo $row['category_id']?>')" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
											</div>
												</td>
												
											</tr>
											<?}?>
										</tbody>
										
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
		
        <!--**********************************
            Content body end
        ***********************************-->
		<!-- Scrollable modal -->
		<div class="modal fade" id="modalGrid">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
				  <div class="modal-header">
					<h5 class="modal-title" id="#gridSystemModal">Add Employee</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				  </div>	
					<div class="modal-body">
					  <div class="container-fluid">
						<div>
							<label>Profile Picture</label>
							<div class= "setting-img d-flex align-items-center mb-4">
								 <div class="avatar-upload d-flex align-items-center">
									<div class=" change position-relative d-flex">
										<div class="avatar-preview">
											<div id="imagePreview" style="background-image: url(page-error-404.html);"> 			
											</div>
										</div>
										<div class="change-btn d-flex align-items-center flex-wrap">
											<input type='file' class="form-control"  id="imageUpload" accept=".png, .jpg, .jpeg" >
											<label for="imageUpload" class="dlab-upload">Choose File</label>
											<a href="javascript:void" class="btn remove-img ms-2">Remove</a>
										</div>
									</div>
										
								</div>
									
							</div>
						</div>
						<form>
							<div class="row">
								<div class="col-xl-6 mb-3">
									<label for="exampleFormControlInput1" class="form-label">Employee ID <span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="">
								</div>	
								<div class="col-xl-6 mb-3">
									<label for="exampleFormControlInput2" class="form-label">Employee Name<span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="exampleFormControlInput2" placeholder="">
								</div>	
								<div class="col-xl-6 mb-3">
									<label for="exampleFormControlInput3" class="form-label">Employee Email<span class="text-danger">*</span></label>
									<input type="email" class="form-control" id="exampleFormControlInput3" placeholder="">
								</div>
								<div class="col-xl-6 mb-3">
									<label for="exampleFormControlInput4" class="form-label">Password<span class="text-danger"></span></label>
									<input type="password" class="form-control" id="exampleFormControlInput4" placeholder="">
								</div>								
							</div>
						</form>
					  </div>
					</div>		
				</div>		
			</div>		
		</div>		
		
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
               <p>Copyright © Developed by <a href="https://dexignzone.com/" target="_blank">DexignZone</a> 2023</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
		
		<div class="offcanvas offcanvas-end customeoff" tabindex="-1" id="offcanvasExample1">
		  <div class="offcanvas-header">
		  <h5 class="modal-title" id="#gridSystemModal1">Add New Task</h5>
			<button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close">
				<i class="fa-solid fa-xmark"></i>
			</button>
		  </div>
		  <div class="offcanvas-body">
			<div class="container-fluid">
				<form>
					<div class="row">
						<div class="col-xl-6 mb-3">
							<label for="exampleFormControlInputfirst" class="form-label">Title<span class="text-danger">*</span></label>
							<input type="text" class="form-control" id="exampleFormControlInputfirst" placeholder="Title">
						</div>	
						<div class="col-xl-6 mb-3">
							<label class="form-label">Project<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Project</option>
								<option value="html">Salesmate</option>
								<option value="css">ActiveCampaign</option>
								<option value="javascript">Insightly</option>
							</select>
						</div>	
						<div class="col-xl-6 mb-3">
							<label for="exampleFormControlInputthree" class="form-label">Start Date<span class="text-danger">*</span></label>
							<input type="date" class="form-control" id="exampleFormControlInputthree">
						</div>
						<div class="col-xl-6 mb-3">
							<label for="exampleFormControlInputfour" class="form-label">End Date<span class="text-danger">*</span></label>
							<input type="date" class="form-control" id="exampleFormControlInputfour">
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Estimated Hour<span class="text-danger">*</span></label>
							<div class="input-group">
								<input type="text" class="form-control" value="09:30"><span class="input-group-text"><i
											class="fas fa-clock"></i></span>
                            </div>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Status<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Status</option>
								<option value="html">In Progess</option>
								<option value="css">Pending</option>
								<option value="javascript">Completed</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">priority<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">priority</option>
								<option value="html">Hight</option>
								<option value="css">Medium</option>
								<option value="javascript">Low</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Category<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Category</option>
								<option value="html">Designing</option>
								<option value="css">Development</option>
								<option value="javascript">react developer</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Permission<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Permission</option>
								<option value="html">Public</option>
								<option value="css">Private</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Deadline add<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Deadline</option>
								<option value="html">Yes</option>
								<option value="css">No</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Assigned to<span class="text-danger">*</span></label>
							<select class="default-select form-control">
								<option  data-display="Select">Assigned</option>
								<option value="html">Bernard</option>
								<option value="css">Sergey Brin</option>
								<option value="javascript"> Larry Ellison</option>
							</select>
						</div>
						<div class="col-xl-6 mb-3">
							<label class="form-label">Responsible Person<span class="text-danger">*</span></label>
							<input name="tagify" class="form-control py-0 ps-0" value='James, Harry'>
							
						</div>
						<div class="col-xl-12 mb-3">
							<label class="form-label">Description<span class="text-danger">*</span></label>
							<textarea rows="3" class="form-control"></textarea>
						</div>
						<div class="col-xl-12 mb-3">
							<label class="form-label">Summary<span class="text-danger">*</span></label>
							<textarea rows="3" class="form-control"></textarea>
						</div>
						
					</div>
					<div>
						<button class="btn btn-primary me-1">Help Desk</button>
						<button class="btn btn-danger light ms-1">Cancel</button>
					</div>
				</form>
			  </div>
		  </div>
		</div>	
		<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
		  <div class="modal-dialog modal-dialog-center">
			<div class="modal-content">
			  <div class="modal-header">
				<h1 class="modal-title fs-5" id="exampleModalLabel1">Invite Employee</h1>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			  </div>
			  <div class="modal-body">
					<div class="row">
						<div class="col-xl-12">
							<input type="email" class="form-control" placeholder="hello@gmail.com">
							<label class="form-label mt-3">Employment date<span class="text-danger">*</span></label>
							<input class="form-control" type="date">
							<div class="row">
								<div class="col-xl-6">
									<label class="form-label mt-3">First Name<span class="text-danger">*</span></label>
									<div class="input-group">
										<input type="text" class="form-control" placeholder="Name">
									</div>
								</div>
								<div class="col-xl-6">
									<label class="form-label mt-3">Last Name<span class="text-danger">*</span></label>
									<div class="input-group">
										<input type="text" class="form-control" placeholder="Surname">
									</div>
								</div>
							</div>
							<div class="mt-3 invite">
								<label class="form-label">Send invitation email<span class="text-danger">*</span></label>
								<input type ="email" class="form-control " placeholder="+ invite">
							</div>
							
					
						</div>
					</div>
					
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			  </div>
			</div>
		  </div>
		</div>

		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************-->


	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	
	<!-- tagify -->
	<script src="vendor/tagify/dist/tagify.js"></script>
	
	<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="vendor/datatables/js/dataTables.buttons.min.js"></script>
	<script src="vendor/datatables/js/buttons.html5.min.js"></script>
	<script src="vendor/datatables/js/jszip.min.js"></script>
	<script src="js/plugins-init/datatables.init.js"></script>
   
	<!-- Apex Chart -->
	<script src="vendor/bootstrap-datetimepicker/js/moment.js"></script>
	<script src="vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
	

	<!-- Vectormap -->
    <script src="js/custom.js"></script>
	<script src="js/deznav-init.js"></script>
	<script src="js/demo.js"></script>
    <script src="js/styleSwitcher.js"></script>
	
	
	
</body>

<!-- Mirrored from w3crm.dexignzone.com/xhtml/finance.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Aug 2023 09:31:21 GMT -->
</html>